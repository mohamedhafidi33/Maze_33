/*
	La classe Player cr�e un joueur qui existe dans le labyrinthe et
    peut naviguer � l'aide de la fonction PlayerMove. Cela prend
    les entr�es des touches fl�ch�es de l'utilisateur pour d�placer le lecteur. La texture
    changera en fonction de la direction dans laquelle le joueur doit faire face
    bas� sur la fonction PlayerMove
*/

#pragma once
#include "MazeObject.h"
#include "Room.h"

#define IMG_PLAYER_RIGHT "res/Images/PlayerRight.png"
#define IMG_PLAYER_LEFT "res/Images/PlayerLeft.png"
#define IMG_PLAYER_UP "res/Images/PlayerUp.png"
#define IMG_PLAYER_DOWN "res/Images/PlayerDown.png"

class Player :
	public MazeObject
{
private:
	static SDL_Texture * playerTextures[4];
	std::shared_ptr<Room> startRoom;
public:
	Player(std::shared_ptr<Room> setRoom, SDL_Renderer * renderer);
	Player();
	~Player();

	bool hasKey = false;

	//Sets the player back to start
	void SetPlayerToStart(std::shared_ptr<Room> room)
	{
		hasKey = false;
		SetStartRoom(room);
	}

	void ResetPlayer(std::shared_ptr<Room> room)
	{
		SetPlayerToStart(room);

	}

	void SetStartRoom(std::shared_ptr<Room> room)
	{
		startRoom = room;
		SetObjRoom(room);
	}

	//Moves the player based off arrow inputs. Returns true if move is successful, false if move is not.
	bool PlayerMove(SDL_Keycode key, SDL_Renderer * renderer)
	{
		bool successfulMove = false;
		Coordinate testPos = objPos;

		switch (key)
		{
		case SDLK_UP:
			testPos.yPos--;
			break;
		case SDLK_DOWN:
			testPos.yPos++;
			break;
		case SDLK_LEFT:
			testPos.xPos--;
			break;
		case SDLK_RIGHT:
			testPos.xPos++;
			break;
		default:
			std::cout << "Invalide entree!" << std::endl;
			return successfulMove;
			break;
		}

		//Sets player texture based on key input
		curObjTexture = playerTextures[key % 4];

		//Check if the room the player is trying to move to is one of the connected rooms
		auto iter = std::find_if(begin(curObjRoom->connectRooms), end(curObjRoom->connectRooms), [&testPos](std::shared_ptr<Room> nextRoom) {
			return nextRoom->roomPos == testPos;
		});

		//if it is, move to that room
		if (iter != std::end(curObjRoom->connectRooms))
		{
			SetObjRoom(*iter);
			successfulMove = true;
		}
		else
		{
			std::cout << "Vous ne pouvez pas passer!" << std::endl;
			successfulMove = false;
		}
		return successfulMove;
	}

	//Checks for items in the player's position.
	bool CheckForObjects()
	{
		//Pick Up Key
		if (std::find(begin(curObjRoom->roomTypes), end(curObjRoom->roomTypes), Key) != end(curObjRoom->roomTypes))
		{
			hasKey = true;
			std::cout << "Cle collecter!" << std::endl;
		}
		return false;
	}


};

