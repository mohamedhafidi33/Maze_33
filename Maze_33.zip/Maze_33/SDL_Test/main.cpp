/*
	Le fichier cpp principal est l'endroit o� le jeu se d�roule r�ellement. Il comprend le
    l'initialisation des variables SDL et SDL, la cr�ation de labyrinthe et de joueur
    objets et la boucle de jeu qui attend les entr�es de l'utilisateur. Ce jeu
    ne met � jour que ce qui est rendu apr�s les entr�es(inputs) du joueur.
*/

//C++ Libraries
#include <iostream>
#include <math.h>
#include <vector>
//SDL Libraries
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
//Definition des classes
#include "Maze.h"
#include "Player.h"

//Globales variables pour les choses qui ne vont pas changer

//PNG and Text files To Use in this
#define IMG_TITLE "res/Images/Title.png"
#define TEXTFILE "res/Text/TitleFont.ttf"

//les variable d'affichage (Display Variables)  sont conservees
//pour faciliter le changement ou la manipulation
int curWindowWidth = 1024;
int curWindowHeight = 768;

SDL_Rect FullScreen{ 0, 0, curWindowWidth, curWindowHeight };

//Parametres d'affichage du jeu
int GameArea_Width = 1024;
int GameArea_Height = 768;
int GameArea_xOffset=0;
int GameArea_yOffset=0;

SDL_Rect GameAreaFillRect{  GameArea_xOffset,
                            GameArea_yOffset,
							GameArea_Width,
							GameArea_Height };

//Level Complete Screen Information
int LevelComplete_Width = curWindowWidth * 8 / 10;
int LevelComplete_Height = curWindowHeight * 8 / 10;
int LevelComplete_xOffset = curWindowWidth / 10;
int LevelComplete_yOffset = curWindowHeight / 10;;

SDL_Rect levelCompleteFillRect
{
	LevelComplete_xOffset,
	LevelComplete_yOffset,
	LevelComplete_Width,
	LevelComplete_Height
};

SDL_Rect levelCompleteTitleRect
{
	levelCompleteFillRect.x,
	levelCompleteFillRect.y,
	levelCompleteFillRect.w,
	levelCompleteFillRect.h / 3
};

SDL_Rect levelCompleteInfoRect
{
	levelCompleteTitleRect.x,
	levelCompleteTitleRect.y + levelCompleteTitleRect.h,
	levelCompleteTitleRect.w,
	levelCompleteFillRect.h - levelCompleteTitleRect.h
};
//Game Window
SDL_Window* window = NULL;

//Game Renderer
SDL_Renderer* renderer = NULL;

enum GameState{Menu, InGame, LevelComplete};
GameState curGameState = Menu;

//Initialize the SDL2
bool initialization()
{
	bool success = true;
	//Initialize SDL
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL could not initialize! SDL Error: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		//Create window
		window = SDL_CreateWindow("", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, curWindowWidth, curWindowHeight, SDL_WINDOW_SHOWN);
		if (window == NULL)
		{
			printf("Window could not be created! SDL Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			//Create renderer for window
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL)
			{
				printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
				success = false;
			}
			//Initialize Fonts
			else if (TTF_Init() == -1)
			{
				printf("SDL TTF could not initialize");
				success = false;
			}
		}
	}
	return success;
}

//Function to Display a Full Screen Texture based off the file name
void FullScreenTexture(const char* fileName)
{
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);

	SDL_Texture* screenTexture = IMG_LoadTexture(renderer, fileName);
	if (screenTexture == NULL)
	{
		printf("SDL could not load the Texture from ");
		printf(fileName);
		return;
	}
	SDL_RenderCopy(renderer, screenTexture, NULL, &FullScreen);
	SDL_RenderPresent(renderer);
}

//Draw Text On Screen in a set, boxed area
void DrawTextFromRect(std::string text, SDL_Rect * textRect, int fontSize)
{
	//Select Font and Color
	TTF_Font *font = TTF_OpenFont(TEXTFILE, fontSize);
	if (font == NULL)
	{
		printf("SDL could not load the Font from ");
		printf(TEXTFILE);
		return;
	}
	SDL_Color fontColor = { 255, 165, 0, 255 };

	SDL_Surface * textSurface = TTF_RenderText_Solid(font, text.c_str(), fontColor);

	//Offsets required to make the text the proper size and scale on screen
	int text_xOffset = textRect->x + (textRect->w - textSurface->w) / 2;
	int text_yOffset = textRect->y + (textRect->h - textSurface->h) / 2;

	//Creates Texture and Rect for displaying texture
	SDL_Texture * textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
	SDL_Rect DisplayTextRect = { text_xOffset, text_yOffset, textSurface->w, textSurface->h };

	//Adds Texture and Outline to Renderer
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderFillRect(renderer, textRect);
	SDL_RenderCopy(renderer, textTexture, NULL, &DisplayTextRect);
	SDL_SetRenderDrawColor(renderer, 255, 165, 0, 255);
	SDL_RenderDrawRect(renderer, textRect);
}

//Draw Text based off parameters passed
void DrawTextFromRectParams(std::string text, int xOffset, int yOffset, int width, int height, int fontSize)
{
	//Create Rect where Text will go
	SDL_Rect textRect = {
		xOffset,
		yOffset,
		width,
		height
	};
	DrawTextFromRect(text, &textRect, fontSize);
}

// Dessine du texte � l'�cran avec un num�ro � c�t�. C'est plus pour le visuel
// effet de la cha�ne de donn�es centr�e dans une petite bo�te � c�t� de son texte associ�.
void DrawTextWithAdjCenteredNumber(std::string text, std::string count, int xOffset, int yOffset, int width, int height, int fontSize)
{
	//Write Text Portion
	int textXOffset = xOffset;
	int textYOffset = yOffset;
	int textWidth = width - height;
	int textHeight = height;
	DrawTextFromRectParams(text, textXOffset, textYOffset, textWidth, textHeight, fontSize);

	//WriteIntPortion
	int intXOffset = textXOffset + textWidth;
	int intYOffset = yOffset;
	int intWidth = height;
	int intHeight = height;
	DrawTextFromRectParams(count, intXOffset, intYOffset, intWidth, intHeight, fontSize);
}

//Adds Multiple Rows of Text to the Renderer.
void DrawTextMultipleRows(std::vector<std::string> &text, int xOffset, int yOffset, int width, int height, int fontSize)
{
	int rowCount = text.size();
	int rowHeight = height / rowCount;
	for (int i = 0; i < rowCount; i++)
	DrawTextFromRectParams(text[i], xOffset, yOffset + rowHeight * i, width, rowHeight, fontSize);
}
// �cran avant du jeu. Renvoie true si vous appuyez sur la touche �chap ou fermez,
// et renvoie false si vous appuyez sur une autre touche pour continuer le jeu.
bool FrontScreen()
{
	//Create Front End Screen
	FullScreenTexture(IMG_TITLE);

	SDL_Event * startEvent = new SDL_Event;
	while (startEvent->type != SDL_KEYDOWN && startEvent->type != SDL_QUIT)
	{
		//Do something when there is an event
		SDL_WaitEvent(startEvent);
	}
	//If the player hits the ESC key or hits the Close Window button
	return startEvent->key.keysym.sym == SDLK_ESCAPE || startEvent->type == SDL_QUIT;

}
//Pop up after a level is complete. Returns True if Quitting, returns false if staying
bool LevelCompleteScreen()
{
	int LevelComplete_FontSize = 68;

	//Add Background Rect and Outline to Renderer
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderFillRect(renderer, &levelCompleteFillRect);
	SDL_SetRenderDrawColor(renderer, 255, 165, 0, 255);
	SDL_RenderDrawRect(renderer, &levelCompleteFillRect);

	//Add Title To Renderer
	DrawTextFromRect("Level Complete!", &levelCompleteTitleRect, LevelComplete_FontSize);

	//Information in Level Complete Panel
	std::vector<std::string> levelComplete_TextRows = { "You Won", "Good Job!", "Press Space To Continue" };

	//Add Information To Renderer in Multiple Rows
	DrawTextMultipleRows(levelComplete_TextRows,levelCompleteInfoRect.x, levelCompleteInfoRect.y, levelCompleteInfoRect.w, levelCompleteInfoRect.h, 45);
	SDL_RenderPresent(renderer);
	SDL_Event * continueEvent = new SDL_Event;

	//Check for User Input to see what to do next
	while (continueEvent->key.keysym.sym != SDLK_SPACE && continueEvent->type != SDL_QUIT )
	{
		//Do something when there is an event
		SDL_WaitEvent(continueEvent);
	}

	//Quits the Game
	return continueEvent->type == SDL_QUIT;
}

//Renders all necessary objects to the screen
void RenderAllGameObjects(std::shared_ptr<Maze> & maze, std::shared_ptr<Player> & player)
{
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);

	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);

	maze->AddMazeRoomsToRenderer(0);
	player->AddObjToRenderer();

	//Check if the player has the key
	if (!player->hasKey)
		maze->mazeKeyPtr->AddObjToRenderer();

	maze->mazeDoorPtr->AddObjToRenderer();
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	SDL_RenderPresent(renderer);
}

int main(int argc, char *argv[])
{
	//Initialize SDL2
	if (!initialization())
	{
		printf("Failed to initialize!\n");
	}
	else
	{
		//Sets the Level, step count, and starting lives
		int level = 1;

		//Determines Starting Size of Maze
		int mazeX = 3, mazeY = 3;

		bool firstLoad = true;
		bool quit = false;

		std::shared_ptr<Maze> curMaze;
		std::shared_ptr<Player> curPlayer;

		//Get the SDL Starting Event
		SDL_Event * gameEvent = new SDL_Event;

		//Game Running Loop
		while (!quit && gameEvent->type != SDL_QUIT && curGameState >= Menu)
		{
			//Front End Menu Loop
			while(!quit && gameEvent->type != SDL_QUIT && curGameState == Menu)
			{
				//Show the Front Screen
				quit = FrontScreen();

				//If Close Window or ESC key is pressed, quit the game
				if (quit)
				{
					break;
				}
				else
				{
					curGameState = InGame;

					//First time the game is loaded
					if (firstLoad)
					{
						curMaze = std::shared_ptr<Maze>(new Maze(mazeX, mazeY,
							GameArea_xOffset, GameArea_yOffset, GameArea_Width,
							GameArea_Height, renderer, level, false));
						curPlayer = std::shared_ptr<Player>
							(new Player(curMaze->FindRoomByPos(curMaze->startPos),
										renderer));

						firstLoad = false;
					}

				}
				RenderAllGameObjects(curMaze, curPlayer);
			}

			//Gameplay Loop
			while (!quit && gameEvent->type != SDL_QUIT && curGameState == InGame)
			{
				//Do something when there is an event
				SDL_WaitEvent(gameEvent);

				//If the Close Window button is pressed, quit the game
				if (gameEvent->type == SDL_KEYDOWN)
				{
					//Gets the Key Input
					auto keyInput = gameEvent->key.keysym.sym;

					//If "ESC" was pressed, leave the game loop
					if (keyInput == SDLK_ESCAPE)
					{
						curGameState = Menu;
						break;
					}

					//If "R" was pressed, reset the maze, reset the player position, and reduce the player life count by 1
					else if (keyInput == SDLK_r )
					{
					    std::cout<<"R pour reset"<<std::endl;
						curMaze->ResetMaze();
						curPlayer->SetPlayerToStart(curMaze->FindRoomByPos(curMaze->startPos));
					}

					//If the player presses an arrow key, check for a movement
					else if(keyInput == SDLK_DOWN  ||
							keyInput == SDLK_LEFT ||
							keyInput == SDLK_RIGHT ||
							keyInput == SDLK_UP)
					{
						//Moves the Player According to the Key Input
						if (curPlayer->PlayerMove(keyInput, renderer))
						{
							//Update the Maze
							curMaze->NextMazeCycle();

							if(curPlayer->CheckForObjects()){}

							if ((curPlayer->objPos == curMaze->finalPos &&
								curPlayer->hasKey))
							{
								curGameState = LevelComplete;
							}

						}
					}
					else {
						std::cout << "Invalide entree" << std::endl;
					}
					RenderAllGameObjects(curMaze, curPlayer);
				}
			}

			//Level Complete Loop
			while (!quit && gameEvent->type != SDL_QUIT && curGameState == LevelComplete)
			{
				//Display level complete stats
				quit = LevelCompleteScreen();
				if (quit)
				{
					break;
				}
				std::cout<<"Congratulation!"<<std::endl;
				curGameState = InGame;

				//Next Level Changes
				SDL_RenderClear(renderer);

				//Increment level count
				level++;

				//Increment Maze Size
				mazeX += 1;
				mazeY += 1;

				curMaze->NextLevelMaze();

				curPlayer->SetPlayerToStart(curMaze->FindRoomByPos(curMaze->startPos));

				RenderAllGameObjects(curMaze, curPlayer);
			}


		}
	}
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	return 0;
}
