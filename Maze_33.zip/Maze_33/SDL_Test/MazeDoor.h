/*
	La classe MazeDoor d�finit le point final que le joueur essaie
    atteindre. Il est repr�sent� par une texture d'un tr�sor et est plac� dans le
    pi�ce la plus �loign�e de la pi�ce de d�part dans le labyrinthe (termin� lorsque
    cr�ation du labyrinthe dans la classe Maze).
*/

#pragma once
#include "MazeObject.h"
#define IMG_MAZEDOOR "res/Images/Lock.png"
class MazeDoor :
	public MazeObject
{
private:
	static SDL_Texture * doorTexture;
public:
	MazeDoor(std::shared_ptr<Room> setRoom);
	~MazeDoor();
};

