#include "Coordinate.h"

Coordinate::Coordinate(int x, int y): xPos(x), yPos(y)
{
}

Coordinate::Coordinate()
{
}


Coordinate::~Coordinate()
{
}
